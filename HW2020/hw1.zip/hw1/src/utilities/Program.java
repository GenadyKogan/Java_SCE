package utilities;

import java.util.ArrayList;
import components.Junction;
import components.Road;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point p=new Point(2,1);
		Junction j=new Junction("aaaa", p);
		ArrayList<String> allowed=new ArrayList<String>();

		Road r=new Road(j, j, allowed, true,true);
		System.out.println(allowed);
		System.out.println(r.setAllowedVehicles(allowed));
		String s="red";
		
		
	}

}
