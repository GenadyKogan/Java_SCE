package Lab5;
import javax.swing.*;
public class Calc3DFrame extends JFrame{
	public Calc3DFrame(){
		this.setTitle("Box Volue & are");
		
	}
}
