
public interface Sale {
	public float getCom();
	public String getSaleName();
	
}
