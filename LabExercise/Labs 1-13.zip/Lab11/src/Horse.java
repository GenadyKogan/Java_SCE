
public interface Horse {
	int getDistance();
	void start();
	void run();
	String getName();
}
